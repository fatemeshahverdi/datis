<?php
$lvl=4;
require_once '../user/../lib/security.php';
require_once './template/header.php';

?>

</div>
<div dir="rtl" ><a href="aboutUs.php">درباره ما</a> <br> <a href="gallery.php">گالری</a> <br> <a href="contactUs.php">تماس با ما</a> <br> <a href="merck.php">مرک</a> <br> <a href="sigma.php">سیگما</a> <br> <a href="labware.php">شیشه آلات</a></div>
<div>
<?php
    require_once './template/footer.php';
?>