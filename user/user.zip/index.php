<?php
header('location:./panel.php');
exit();