<?php
$lvl=8;
require_once '../user/../lib/security.php';
require_once './template/header.php';

?>

</div>
<div dir="rtl" ><a href="keyword.php">کلمات کلیدی</a><br><a href="./GaleryChangePics.php">تصاویر بنر</a> <br><a href="./logo.php">logo</a> <br> <a href=""></a> </div>
<div>
<?php
    require_once './template/footer.php';
?>