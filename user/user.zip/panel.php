<?php
$lvl=0;
require_once '../lib/security.php';
$ti="پنل مدیریتی";
require_once 'template/header.php';
?>

</div>

   <div>

<?php
  require_once './template/footer.php';
?>
